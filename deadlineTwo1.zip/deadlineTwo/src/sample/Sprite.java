package sample;

public class Sprite {
}
