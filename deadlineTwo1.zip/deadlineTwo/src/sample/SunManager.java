package sample;

import javafx.scene.image.Image;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;
import java.util.logging.Level;

import static java.lang.System.currentTimeMillis;

public class SunManager implements Serializable {

    private long lastUpdate;
    private Random random;
    private GameController gameController;
    private int numLanes;
    private int offset;

    SunManager(GameController gameController, int level){
        this.gameController = gameController;
        lastUpdate = currentTimeMillis();
        random = new Random();
        this.numLanes = LevelManager.numLanes(level);
        this.offset = LevelManager.offset(level);
    }

    public void update(boolean isPaused){
        if(isPaused){
            lastUpdate = currentTimeMillis();
            return;
        }
        long currentTime = currentTimeMillis();
        if(currentTime - lastUpdate > 10000){
            lastUpdate = currentTime;
            new Sun(random.nextInt(9), random.nextInt(numLanes)  + offset, true, gameController);
        }
    }

}
